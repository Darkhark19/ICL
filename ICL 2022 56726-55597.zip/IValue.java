public interface IValue {
    String toStr();
}

