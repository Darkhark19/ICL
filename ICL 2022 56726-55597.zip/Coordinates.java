public class Coordinates {
    int left;
    String right;

    public Coordinates(int left, String right){
        this.left = left;
        this.right = right;
    }

    
    
}
