public interface IType {
    String toStr();

    String toJasmin();
}